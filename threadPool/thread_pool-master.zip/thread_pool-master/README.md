thread_pool
===========

advanced thread pools with dynamic adjustment

look for the url：http://blog.csdn.net/lingfengtengfei/article/details/9038633
and http://blog.csdn.net/lingfengtengfei/article/details/9039135 

